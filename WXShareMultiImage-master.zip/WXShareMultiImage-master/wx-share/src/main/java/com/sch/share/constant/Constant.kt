package com.sch.share.constant

/**
 * Created by StoneHui on 2019-11-28.
 *
 *
 * 常量
 */

const val WX_PACKAGE_NAME = "com.tencent.mm"
const val WX_LAUNCHER_UI = "com.tencent.mm.ui.LauncherUI"
const val WX_SHARE_IMG_UI = "com.tencent.mm.ui.tools.ShareImgUI"
const val WX_SHARE_TO_TIMELINE_UI = "com.tencent.mm.ui.tools.ShareToTimeLineUI"